gcc main.c cpuSim.c control.c -o cpuSim;
./cpuSim
